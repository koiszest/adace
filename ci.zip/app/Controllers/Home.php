<?php

namespace App\Controllers;

class Home extends BaseController
{
	public function index()
	{
		$post_model = model('post_model');
		$data = [
			'posts' => $post_model->getNewPosts(),
		];
		$user = model('user_model');
		$data['login_status'] = $user->check_login();
		echo view('header');
		echo view('index', $data);
		echo view('footer');
	}

	//--------------------------------------------------------------------
	public function vue()
	{
		echo view('header');
		echo view('vue');
		echo view('footer');
	}
}
