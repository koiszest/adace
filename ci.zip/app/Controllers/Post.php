<?php

namespace App\Controllers;

/**
 * Class BaseController
 *
 * BaseController provides a convenient place for loading components
 * and performing functions that are needed by all your controllers.
 * Extend this class in any new controllers:
 *     class Home extends BaseController
 *
 * For security be sure to declare any new methods as protected or private.
 *
 * @package CodeIgniter
 */

use CodeIgniter\Controller;

class Post extends Controller
{

	/**
	 * An array of helpers to be loaded automatically upon
	 * class instantiation. These helpers will be available
	 * to all other controllers that extend BaseController.
	 *
	 * @var array
	 */
	protected $helpers = ['form'];

	/**
	 * Constructor.
	 */
	public function initController(\CodeIgniter\HTTP\RequestInterface $request, \CodeIgniter\HTTP\ResponseInterface $response, \Psr\Log\LoggerInterface $logger)
	{
		// Do Not Edit This Line
		parent::initController($request, $response, $logger);

		//--------------------------------------------------------------------
		// Preload any models, libraries, etc, here.
		//--------------------------------------------------------------------
		// E.g.:
		// $this->session = \Config\Services::session();
	}
	public $data;
	public function index($page = 'post_index', $data = [])
	{
		$user = model('user_model');
		$data['login_status'] = $user->check_login();
		echo view('header');
		echo view($page, $data);
		echo view('footer');
	}
	public function edit($data2 = [])
	{
		$resuest = service('request');
		if ($data2 = []) {
			$data['post_create'] = false;
			$data['post_success'] = false;
			$data['post']  = [
				'title' => '',
				'author' => '',
				'text' => ''
			];
			$this->index('post_edit');
		} else {
			$data['post_create'] = false;
			$data['post_success'] = false;
			$data['post']  = new class
			{
				public $title;
				var $author;
				var $text;
			};
			$data['post']->title = $data2['title'];
			$data['post']->author = $data2['author'];
			$data['post']->text = $data2['text'];
			$this->index('post_edit', $data);
		}
	}
	public function create()
	{
		$request = service('request');
		/*
        $data['title'] = base64_encode($request->getPost('title'));
        $data['author'] = base64_encode($request->getPost('author'));
		$data['text'] = base64_encode($request->getPost('text'));*/
		$data['title'] = $request->getPost('title');
		$data['author'] = $request->getPost('author');
		$data['text'] = $request->getPost('text');
		$model = model('post_model');
		$result = $model->create($data);
		$data['post_create'] = true;
		if ($result) $data['post_success'] = true;
		else $data['post_success'] = false;
		$this->data = $data;
		$this->index("post_edit", $data);
		//header('refresh:3;editor');
	}
	public function editor()
	{
		$data2 = $this->data;
		$data['post_create'] = true;
		$data['post_success'] = $this->data['post_success'];
		$data['post']  = new class
		{
			public $title;
			var $author;
			var $text;
		};
		$data['post']->title = $data2['title'];
		$data['post']->author = $data2['author'];
		$data['post']->text = $data2['text'];
		$this->index('post_edit');
	}
	public function view($pid = 1){
		$model = model('post_model');
		$data = $model->getPostById($pid);
		$this->index('post_view',[ 'post' => $data[0]]);
	}
}
