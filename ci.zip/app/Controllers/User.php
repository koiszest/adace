<?php

namespace App\Controllers;

use CodeIgniter\Controller;

class User extends Controller
{

	/**
	 * An array of helpers to be loaded automatically upon
	 * class instantiation. These helpers will be available
	 * to all other controllers that extend BaseController.
	 *
	 * @var array
	 */
	protected $helpers = ['form'];


	public function initController(\CodeIgniter\HTTP\RequestInterface $request, \CodeIgniter\HTTP\ResponseInterface $response, \Psr\Log\LoggerInterface $logger)
	{

		parent::initController($request, $response, $logger);
	}
	public function index($page = 'user_login', $data = [])
	{
		echo view('header');
		echo view($page, $data);
		echo view('footer');
	}
	public function login()
	{
		$this->index('user_login');
	}
	public function match()
	{
		$request = service('request');
		$user = model('user_model');
		$info = $user->getInfoByName($request->getPost('username'));
		$info = $info[0];
		if (!$info) {
			$data['login_success'] = false;
			$data['user_login'] = true;
		} else {
			$data['login_success'] = false;
			$data['user_login'] = true;
			if ($info->name == $request->getPost('username') && $info->password == $request->getPost('password')) {
				$data['login_success'] = true;
				$session = \Config\Services::session();
				$session->set('adace_login', 'yes');
				$info->password = null;
				$session->set('adace_user', $info);
			}
		}
		$this->index('user_login', $data);
	}
}
