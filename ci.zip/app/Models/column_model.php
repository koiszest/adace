<?php
namespace  App\Models;
use CodeIgniter\Model;
    class column_model extends Model{
        public function create($data){
            $db = model('db_model');
            return $db->insert('column',$data);
        }
        public function del($data){
            $db = model('db_model');
            return $db->delete('column',$data);
        }
        public function edit($data){
            $db = model('db_model');
            return $db->update('column',$data);
        }
        public function get($data){
            $db = model('db_model');
            return $db->selectBy('column',$data[0],$data[1]);
        }
        public function getAll(){
            $db = model('db_model');
            return $db->selectAll('column');
        }
    }
