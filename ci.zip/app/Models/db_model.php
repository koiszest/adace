<?php
namespace App\Models;
use CodeIgniter\Model;
    //this model aim to do update , insert and delete things in the database,so as not to repeat same codes 
    //$data must be an array like this ['key'=>'value']
    class db_model{
        public $db;
        private $result;
        public function __construct(){
            $this->db = \Config\Database::connect();
            $this->db->query("set names UTF8");
        }
        public function select($table){
            $builder = $this->db->table($table);
            return $builder;
        }

        public function selectBy($table,$key,$value){
            $builder = $this->db->table($table);
            $query = $builder->where($key,$value);
            $result = $query->get();
            return $result->getRow();
        }
        public function update($table,$data){
            $builder = $this->db->table($table);
            $builder->replace($data);
            return $this->db->affectedRows();
        }
        public function insert($table, $data){
            $builder = $this->db->table($table);
            $builder->insert($data);
            return $this->db->affectedRows();
        }
        public function delete($table,$data){
            $builder = $this->db->table($table);
            $builder->delete($data);
            return $this->db->affectedRows();
        }
    }