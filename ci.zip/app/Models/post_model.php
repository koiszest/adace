<?php
namespace App\Models;
use CodeIgniter\Model;
    class post_model extends Model{
        public function create($data){
            $data = array(
                'title' => $data['title'],
                'author' => $data['author'],
                'text' => $data['text']
        );
        $db = model('db_model');
        return $db->insert('post',$data);
        }
        public function edit($data){
            $db = model('db_model');
            return $db->update('post',$data);
        }
        public function remove($data){
            $db = model('db_model');
            return $db->delete('post',$data);
        }
        public function getNewPosts(){
            $db = model('db_model');
            $builder = $db->select('post');
            $builder->orderBy('pid','DESC');
            $result = $builder->get();
            return $result->getResult();
        }
        public function getPostById($pid){
            $db = model('db_model');
            $builder = $db->select('post');
            $result = $builder->getWhere(['pid' => $pid]);
            return $result->getResult();
        }
    }