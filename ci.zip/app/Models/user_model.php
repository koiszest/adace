<?php
    namespace App\Models;
    use CodeIgniter\Model;
    class user_model extends Model{
        //check the username and password, if both correct return true,otherwise return false
        //$data must contain username and password
            public function login($data){
                $db = model('db_model');
                $row = $db->selectBy('user','name',$data['username']);
                if($row['name'] == $data['username'] && $row['password'] == base64_encode($data['password'])) 
                return true;
                return false;
            }

            //$data must contain name , password and email address
            public function register($data){
                $data = array(
                'name' => $data['name'],
                'password' => base64_encode($data['password']),
                'email' => $data['email']
                );
                $db = model('db_model');
                return $db->insert('user',$data);
            }

            //$data must have be array like "key" => "value"
            public function edit($data){
                $db = model('db_model');
                return $db->update('user',$data);
            }

	        public function getInfoByName($name){
		        $db = model('db_model');
		        $builder = $db->select('user');
                $result = $builder->getWhere(['name' => $name]);
                return $result->getResult();
            }
            // 1 already logined , 0 not yet
            public function  check_login(){
                $session = \Config\Services::session();
                if(isset($_SESSION['adace_login']) && $_SESSION['adace_login'] == 'yes'){
                    return true;
                }else{
                    return false;
                }
            }
            
    }
?>