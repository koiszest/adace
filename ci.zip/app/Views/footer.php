<div style="color:gray;text-align:center;size:2em;">@2020 粤CD55612</div>
</div>
<script src="<?= base_url('app.js') ?>"></script>
</body>

</html>