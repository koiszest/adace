<!DOCTYPE html>
<html lang="en">

<head>
  <?php header("Content-type:text/html;charset=utf-8"); ?>
  <meta charset="UTF8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="<?= base_url('bootstrap.min.css') ?>">
  <script src="<?= base_url('vue.js') ?>"></script>
  <script src="https://cdn.tiny.cloud/1/is25c4rcqp3fhr77sxm0clq3jmmgelcd6m6n3xs1d1x86osg/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.0/dist/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>

  <title>Adace bbs</title>
</head>

<body style="height:100%;">
  <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <a class="navbar-brand" href="<?= site_url('home') ?>">Adace</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarColor01">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item active">
          <a class="nav-link" href="<?= site_url('home') ?>">首页 <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?= site_url('post/edit') ?>">发帖</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?= site_url('user/login') ?>">登录</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?= site_url('user/register') ?>">注册</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">菜单</a>
          <div class="dropdown-menu">
            <a class="dropdown-item" href="#">BB馆</a>
            <a class="dropdown-item" href="#">夏日亡灵</a>
            <a class="dropdown-item" href="#">留言板</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="#">友链</a>
          </div>
        </li>
      </ul>
      <form class="form-inline my-2 my-lg-0">
        <input class="form-control mr-sm-2" type="text" placeholder="Search Something">
        <button class="btn btn-secondary my-2 my-sm-0" type="submit">Search</button>
      </form>
    </div>
  </nav>
  <div class="jumbotron" style="margin-bottom:0;padding-bottom:0;height:100%;">