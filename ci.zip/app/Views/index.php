<h2 class="display-5">欢迎来到Adace!</h2>
<p class="lead">全新的设计，更贴近移动端。</p>
<hr class="my-4">
<p>每一个不曾起舞的日子，都是对生命的辜负。——尼采</p>

<?php if(!$login_status){?>
<div id="msgbox">
  <div class="toast show" role="alert" aria-live="assertive" aria-atomic="true" v-bind:style="msgboxstyle">
    <div class="toast-header">
      <strong class="mr-auto" title="hello">Adace</strong>
      <small>1 seconds ago</small>
      <button type="button" class="ml-2 mb-1 close" data-dismiss="toast" aria-label="Close">
        <span aria-hidden="true" v-on:click="closemsgbox">&times;</span>
      </button>
    </div>
    <div class="toast-body">
      登录享受更多功能！
    </div>
  </div>
</div>
<?php }?>


<button type="button" class="btn btn-primary btn-lg btn-block">最新帖子</button>

<?php foreach ($posts as $post) : ?>
  <div class="card">
    <div class="card-body">
      <h4 class="card-title"><?= $post->title ?></h4>
      <h6 class="card-subtitle mb-2 text-muted"><?= $post->author ?> / <?= $post->date ?></h6>
      <p class="card-text"><?= $post->text ?></p>
      <a href="<?= site_url('post/view/'.$post->pid) ?>" class="card-link">查看更多</a>
      <a href="#" class="card-link">查看作者</a>
    </div>
  </div>
  <hr class="my-4">
<?php endforeach; ?>
