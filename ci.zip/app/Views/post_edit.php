<?php if(!$login_status){?>
  <div class="alert alert-dismissible alert-warning">
  <button type="button" class="close" data-dismiss="alert">&times;</button>
  <h4 class="alert-heading">Warning!</h4>
  <p class="mb-0">你还没有登录，不能发帖。请 <a href="<?=site_url('user/login')?>" class="alert-link">登录</a>.</p>
</div>

<?php 
}else{
?>

<?php if ($post_create && $post_success) { ?>
  <div class="alert alert-dismissible alert-success">
    <button type="button" class="close" data-dismiss="alert">&times;</button>
    <strong>你的帖子已经修改或发布成功!</strong> 现在点击 <a href="<?=site_url('home')?>" class="alert-link">立即查看</a> 或者继续撰写新文章.
  </div>
<?php } elseif ($post_create && !$post_success) { ?>
  <div class="alert alert-dismissible alert-danger">
    <button type="button" class="close" data-dismiss="alert">&times;</button>
    <strong>我的天啊!</strong> 你的帖子发布失败了，请重试！
  </div>
<?php } ?>

<?= form_open("Post/create") ?>
<div class="form-group">
  <label class="col-form-label col-form-label-lg" for="inputLarge">主题</label>
  <input class="form-control form-control-lg" type="text" placeholder="" id="inputLarge" name="title" value="<?= $post->title ?>">
</div>

<div class="form-group">
  <label class="col-form-label" for="inputDefault">作者</label>
  <input type="text" class="form-control" placeholder="" id="inputDefault" name="author" value="<?= $post->author ?>">
</div>

<div id="editor" class="border:1px solid #fff;"></div>
<label for="exampleTextarea">正文</label>
<div class="form-group" id="wan">

  <textarea class="form-control" id="wang" rows="10" name="text"><?= $post->text ?></textarea>
</div>

<fieldset class="form-group">
  <button type="submit" class="btn btn-primary">Submit</button>
</fieldset>
</form>

<?php }?>