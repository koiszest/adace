<div class="card mb-3">
  <h3 class="card-header"><?=$post->title?></h3>
  <div class="card-body">
    <h5 class="card-title"><?=$post->author?> / <?=$post->date?></h5>
    <h6 class="card-subtitle text-muted">文章ID <?=$post->pid?> / 栏目ID <?=$post->cid?></h6>
  </div>
  <img style="height: 200px; width: 100%; display: block;" src="data:image/svg+xml;charset=UTF-8,%3Csvg%20width%3D%22318%22%20height%3D%22180%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%20318%20180%22%20preserveAspectRatio%3D%22none%22%3E%3Cdefs%3E%3Cstyle%20type%3D%22text%2Fcss%22%3E%23holder_158bd1d28ef%20text%20%7B%20fill%3Argba(255%2C255%2C255%2C.75)%3Bfont-weight%3Anormal%3Bfont-family%3AHelvetica%2C%20monospace%3Bfont-size%3A16pt%20%7D%20%3C%2Fstyle%3E%3C%2Fdefs%3E%3Cg%20id%3D%22holder_158bd1d28ef%22%3E%3Crect%20width%3D%22318%22%20height%3D%22180%22%20fill%3D%22%23777%22%3E%3C%2Frect%3E%3Cg%3E%3Ctext%20x%3D%22129.359375%22%20y%3D%2297.35%22%3EImage%3C%2Ftext%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fsvg%3E" alt="Card image">
  <div class="card-body">
    <p class="card-text"><?=$post->text?></p>
  </div>
</div>
<div class="card">
  <div class="card-body">
    <h4 class="card-title">留言区</h4>
    <h6 class="card-subtitle mb-2 text-muted">subtitle</h6>
    <p class="card-text">本功能暂未开放.</p>

    <div style="display:none;">
  <ul class="pagination">
    <li class="page-item disabled">
      <a class="page-link" href="#">&laquo;</a>
    </li>
    <li class="page-item active">
      <a class="page-link" href="#"></a>
    </li>
    <li class="page-item">
      <a class="page-link" href="#"></a>
    </li>
    <li class="page-item">
      <a class="page-link" href="#"></a>
    </li>
    <li class="page-item">
      <a class="page-link" href="#"></a>
    </li>
    <li class="page-item">
      <a class="page-link" href="#"></a>
    </li>
    <li class="page-item">
      <a class="page-link" href="#">&raquo;</a>
    </li>
  </ul>
</div>

    <a href="<?=site_url('home')?>" class="card-link">返回首页</a>
    <a href="<?=site_url('home')?>" class="card-link">返回首页</a>
  </div>
</div>