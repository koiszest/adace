<?php if ($login_success && $user_login) : ?>
    <div class="alert alert-dismissible alert-success">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
        <strong>恭喜你登陆成功!</strong> 你要返回 <a href="<?=site_url('home')?>" class="alert-link">首页</a>吗？
    </div>
<?php endif; ?>
<?php if (!$login_success && $user_login) : ?>
    <div class="alert alert-dismissible alert-danger">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
        <strong>我的天!登录失败了！请检查 账号 和 密码 再重试。</strong> 
    </div>
<?php endif; ?>
<?= form_open("User/match") ?>

<div class="card text-white bg-primary mb-3" style="max-width: 20rem;">
    <div class="card-header">Adace</div>
    <div class="card-body">
        <h4 class="card-title">用户登录</h4>
        <div class="form-group">
            <label class="col-form-label" for="inputDefault">Username</label>
            <input type="text" class="form-control" placeholder="用户名" name="username">
        </div>

        <div class="form-group">
            <label for="exampleInputPassword1">Password</label>
            <input type="password" class="form-control" name="password" placeholder="密码">
        </div>

        <fieldset class="form-group">
            <button type="submit" class="btn btn-success">Login</button>
        </fieldset>
        </form>
        <p class="card-text">任何你的不足，在你成功的那刻，都会被人说为特色。所以，坚持做你自己，而不是在路上被别人修改的面目全非。</p>
    </div>
</div>