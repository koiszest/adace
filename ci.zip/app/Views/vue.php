<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script type="javascript" src="<?= base_url('public/vue.js') ?>"></script>
    <title>Document</title>
</head>

<body>
    <div id='app'>
        </id>
</body>

</html>