tinymce.init({
    selector: '#wang', //容器，可使用css选择器
    plugins: 'a11ychecker advcode casechange formatpainter linkchecker autolink lists checklist media mediaembed pageembed permanentpen powerpaste table advtable tinycomments tinymcespellchecker',
      toolbar: 'a11ycheck addcomment showcomments casechange checklist code formatpainter pageembed permanentpen table',
      toolbar_mode: 'floating',
      tinycomments_mode: 'embedded',
      tinycomments_author: 'Author name',
});
var vm = new Vue({
    el: '#msgbox',
    data: {
        ab: 'hello',
        msgboxstyle: 'display:null;'
    },
    methods: {
        closemsgbox: function () {
            this.msgboxstyle = "display:none;"
            console.log("hello")
        }
    }
})